package top.syhan.java.basic.annotation;

/**
 * @program: java-basic
 * @description:
 * @author: SYH
 * @Create: 2021-11-10 15:39
 **/
//@TestAnnotation(id = 3, msg = "hello annotation")
@TestAnnotation
public class Test {
}
