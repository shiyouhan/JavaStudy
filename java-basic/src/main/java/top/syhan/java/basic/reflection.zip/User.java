package top.syhan.java.basic.reflection;

import javax.print.attribute.standard.OrientationRequested;

/**
 * @program: java-basic
 * @description:
 * @author: SYH
 * @Create: 2021-11-09 21:19
 **/
public class User {
    private Integer id;
    private String name;

    public User(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public User() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
