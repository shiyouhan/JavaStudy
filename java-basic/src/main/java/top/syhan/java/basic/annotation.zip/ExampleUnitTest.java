package top.syhan.java.basic.annotation;

import org.junit.Test;

/**
 * @program: java-basic
 * @description:
 * @author: SYH
 * @Create: 2021-11-10 16:11
 **/
public class ExampleUnitTest {
    @Test
    public void additionIsCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }

    private void assertEquals(int i, int i1) {
    }
}
