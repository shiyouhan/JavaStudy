package top.syhan.java.basic.annotation;

/**
 * @program: java-basic
 * @description:
 * @author: SYH
 * @Create: 2021-11-10 15:34
 **/
@Person(role = "CEO")
@Person(role = "husband")
@Person(role = "father")
@Person(role = "son")
public class Man {
    String name = "";
}
