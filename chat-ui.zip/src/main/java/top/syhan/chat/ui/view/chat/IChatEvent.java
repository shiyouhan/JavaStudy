package top.syhan.chat.ui.view.chat;

/**
 * @program: chat-ui
 * @description: 事件接口类
 * @author: SYH
 * @Create: 2021-10-22 22:04
 **/
public interface IChatEvent {
}
