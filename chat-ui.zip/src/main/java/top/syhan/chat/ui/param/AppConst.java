package top.syhan.chat.ui.param;

/**
 * @program: chat-ui
 * @description: 系统常量
 * @author: SYH
 * @Create: 2021-10-24 18:00
 **/
public class AppConst {

    public static final int TALK_SKETCH_LENGTH = 30;

    public static int FACE_COUNT = 15;
}
